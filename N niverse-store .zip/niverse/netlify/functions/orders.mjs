import {store,json,label} from '../lib/orders.mjs';
export const config={path:'/api/orders'};
// Fulfilment list: GET /api/orders with header x-admin-key: <ADMIN_KEY>
export default async req=>{
 if(!process.env.ADMIN_KEY||req.headers.get('x-admin-key')!==process.env.ADMIN_KEY)return json({error:'Unauthorized'},401);
 const s=store(),{blobs}=await s.list(),out=[];
 for(const {key} of blobs){const o=await s.get(key,{type:'json'});if(o?.status==='paid')out.push({...o,summary:o.items.map(label)})}
 return json(out.sort((a,b)=>b.paidAt.localeCompare(a.paidAt)));
};
