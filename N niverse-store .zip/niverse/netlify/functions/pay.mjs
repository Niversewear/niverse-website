import {store,price,json} from '../lib/orders.mjs';
export const config={path:'/api/pay'};
export default async req=>{
 if(req.method!=='POST')return json({error:'POST only'},405);
 try{
  const {provider,items,customer}=await req.json();
  if(!['paystack','flutterwave'].includes(provider))return json({error:'Unknown provider'},400);
  const c={};for(const k of['name','email','phone','address','city','state'])c[k]=String(customer?.[k]||'').slice(0,200);
  if(!c.email||!c.name||!c.address)return json({error:'Missing delivery details'},400);
  const amount=price(items),site=process.env.SITE_URL||new URL(req.url).origin;
  const ref='NV-'+Date.now().toString(36).toUpperCase()+Math.random().toString(36).slice(2,6).toUpperCase();
  const clean=items.map(({id,size,color,q})=>({id,size,color,q:Math.floor(q)}));
  await store().setJSON(ref,{ref,provider,items:clean,customer:c,amount,status:'pending',createdAt:new Date().toISOString()});
  if(provider==='paystack'){
   const d=await(await fetch('https://api.paystack.co/transaction/initialize',{method:'POST',headers:{Authorization:'Bearer '+process.env.PAYSTACK_SECRET_KEY,'Content-Type':'application/json'},body:JSON.stringify({email:c.email,amount:amount*100,currency:'NGN',reference:ref,callback_url:site+'/?p=paystack'})})).json();
   return d.status?json({url:d.data.authorization_url}):json({error:d.message},502)}
  const d=await(await fetch('https://api.flutterwave.com/v3/payments',{method:'POST',headers:{Authorization:'Bearer '+process.env.FLW_SECRET_KEY,'Content-Type':'application/json'},body:JSON.stringify({tx_ref:ref,amount,currency:'NGN',redirect_url:site+'/?p=flutterwave',customer:{email:c.email,name:c.name,phonenumber:c.phone},customizations:{title:'NIVERSE'}})})).json();
  return d.status==='success'?json({url:d.data.link}):json({error:d.message},502);
 }catch(e){return json({error:e.message==='Invalid cart'||e.message==='Empty cart'?e.message:'Server error'},400)}
};
