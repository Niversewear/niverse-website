import {createHmac} from 'node:crypto';
import {confirm,json} from '../lib/orders.mjs';
export const config={path:'/api/webhook'};
export default async req=>{
 if(req.method!=='POST')return json({},405);
 const raw=await req.text(),b=JSON.parse(raw||'{}');let ref;
 const ps=req.headers.get('x-paystack-signature'),fw=req.headers.get('verif-hash');
 if(ps){if(createHmac('sha512',process.env.PAYSTACK_SECRET_KEY).update(raw).digest('hex')!==ps)return json({},401);
  if(b.event==='charge.success')ref=b.data.reference}
 else if(fw){if(!process.env.FLW_WEBHOOK_HASH||fw!==process.env.FLW_WEBHOOK_HASH)return json({},401);ref=b.data?.tx_ref}
 else return json({},401);
 if(ref)await confirm(ref).catch(()=>{});
 return json({ok:true});
};
