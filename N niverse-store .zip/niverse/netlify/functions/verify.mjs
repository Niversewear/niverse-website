import {confirm,json} from '../lib/orders.mjs';
export const config={path:'/api/verify'};
export default async req=>{
 const ref=new URL(req.url).searchParams.get('ref');if(!ref)return json({paid:false},400);
 try{const o=await confirm(ref);if(!o)return json({paid:false},404);
  return json({paid:o.status==='paid',ref:o.ref,amount:o.amount,items:o.items,name:o.customer.name.split(' ')[0]})}
 catch{return json({paid:false},500)}
};
