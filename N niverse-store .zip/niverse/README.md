# NIVERSE store
Flow: Home → Collection → Product → Size → Bag → Checkout → Paystack/Flutterwave → server verification → Order confirmation. Paid orders are saved in Netlify Blobs.

## Deploy (GitHub → Netlify; functions need a build, not drag-drop)
Environment variables (Site settings → Environment variables):
- PAYSTACK_SECRET_KEY, FLW_SECRET_KEY
- FLW_WEBHOOK_HASH (any secret string; set the same value in Flutterwave dashboard → Webhooks → Secret hash)
- ADMIN_KEY (any long secret, for the orders list)
- SITE_URL (https://yourdomain.com)

Webhooks: set both providers' webhook URL to https://yourdomain.com/api/webhook

View paid orders for fulfilment:
curl -H "x-admin-key: YOUR_ADMIN_KEY" https://yourdomain.com/api/orders

Edit products.json to change products/prices; images live in /images. Replace social links in index.html footer. Test with Paystack/Flutterwave TEST keys first.
